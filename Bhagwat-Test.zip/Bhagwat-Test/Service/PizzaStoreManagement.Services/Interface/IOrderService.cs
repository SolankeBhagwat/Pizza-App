﻿using PizzaStoreManagement.Common.Entities;
using System.Collections.Generic;

namespace PizzaStoreManagement.Services.Interface
{
    public interface IOrderService
    {
        IEnumerable<Order> GetAllOrders();
        int PlaceOrder(Order order);
        object GetOrder(int orderId);
    }
}